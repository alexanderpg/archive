/*662*/
ALTER TABLE `phpshop_delivery` ADD `length_max` INT(11) DEFAULT '0';
ALTER TABLE `phpshop_delivery` ADD `height_max` INT(11) DEFAULT '0';  
ALTER TABLE `phpshop_delivery` ADD `width_max` INT(11) DEFAULT '0';  
ALTER TABLE `phpshop_delivery` ADD `sum_side_max` INT(11) DEFAULT '0';