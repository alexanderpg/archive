ALTER TABLE `phpshop_modules_avangard_system` ADD `version` varchar(64) default '1.1';
ALTER TABLE `phpshop_modules_avangard_system` ADD `qr` varchar(255);